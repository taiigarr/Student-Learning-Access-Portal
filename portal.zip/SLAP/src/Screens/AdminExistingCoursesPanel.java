package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTable;

import portal.Admin;
import portal.Course;
import portal.DataBases;
import portal.Student;
import portal.User;

public class AdminExistingCoursesPanel extends JPanel {
	JFrame parentFrame;
	
	JLabel requestedLbl;
	JButton deleteCourseBtn;
	JButton backBtn;
	JTable studentListTbl;
	
	Collection<Course> values;
	JList<String> list ;
	String[] courseNames;
	String courseName;
	
	User user;
	
	public AdminExistingCoursesPanel(final JFrame parentFrame, final DataBases db, final User user) {
		this.parentFrame = parentFrame;
		this.user = user;
		
		requestedLbl = new JLabel("Current Course List");
		studentListTbl = new JTable();
		deleteCourseBtn = new JButton("Delete");
		backBtn = new JButton("Back");
		
		values = db.getCoursesDB().values();
		Course[] entry = (Course[]) values.toArray(new Course[values.size()]); //x.toArray (new Foo[x.size ()])
		courseNames = new String[entry.length];
		
		int i = 0;
		for (Course course: entry)
			courseNames[i++] = course.getCourseName();
//		for (int i=0; i<entry.length; i++)
//			courseNames[i] = entry[i].getCourseName();
		list = new JList<String>(courseNames); //data has type Object[]
		if ( db.getCoursesDB().isEmpty() )
			deleteCourseBtn.setEnabled(false);
		
		deleteCourseBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				courseName = list.getSelectedValue();
				if (!db.getCoursesDB().isEmpty())
					db.getCoursesDB().remove(courseName);	// remove course from req course db
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		
		this.add(requestedLbl);
		this.add(studentListTbl);
		this.add(list);
		this.add(deleteCourseBtn);
		this.add(backBtn);
	}
}