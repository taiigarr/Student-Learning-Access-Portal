package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;

import portal.Course;
import portal.DataBases;
import portal.Student;
import portal.User;

public class StudentEnrolledCoursesPanel extends JPanel {
	JFrame parentFrame;
	
	JLabel enrollLbl;
	JButton viewAnnouncementsBtn;
	JButton viewGradesBtn;
	JButton backBtn;
	JTable studentListTbl;
	
	Collection<Course> values;
	JList<String> list ;
	String[] courseNames;
	
	public StudentEnrolledCoursesPanel(final JFrame parentFrame, final DataBases db, final User user) {
		this.parentFrame = parentFrame;
		
		enrollLbl = new JLabel("Enrolled Courses");
		studentListTbl = new JTable();
		viewAnnouncementsBtn = new JButton("View Announcements");
		viewGradesBtn = new JButton("View Grades");
		backBtn = new JButton("Back");
		
		values = db.getStuCoursesDB().values();
		Course[] entry = (Course[]) values.toArray(new Course[values.size()]); //x.toArray (new Foo[x.size ()])
		courseNames = new String[entry.length];
		for (int i=0; i<entry.length; i++)
			courseNames[i] = entry[i].getCourseName();
		list = new JList<String>(courseNames); //data has type Object[]
		
		viewGradesBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String courseName = list.getSelectedValue();
				Course course = db.getStuCoursesDB().get(courseName);
				
				if (course==null)
					JOptionPane.showMessageDialog(parentFrame, "Select a course first!");
				else
				{
					parentFrame.getContentPane().removeAll();
					parentFrame.getContentPane().add(new StudentGradesPanel(parentFrame,db,user, course));
					parentFrame.revalidate();
					parentFrame.repaint();
				}
			}
        });	
		viewAnnouncementsBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String courseName = list.getSelectedValue();
				Course course = db.getStuCoursesDB().get(courseName);
				System.out.println("course from db " + course);
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new StudentAnnouncementsPanel(parentFrame, db, user, course));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });	
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new StudentWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });		
		
		this.add(enrollLbl);
		this.add(studentListTbl);
		this.add(list);
		this.add(viewAnnouncementsBtn);
		this.add(viewGradesBtn);
		this.add(backBtn);
	}
}