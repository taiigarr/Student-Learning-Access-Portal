package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

import portal.Course;
import portal.DataBases;
import portal.Student;
import portal.User;

public class StudentGradesPanel extends JPanel {
	JFrame parentFrame;
	
	JLabel announcementsLbl;
	JButton backBtn;
	JLabel gradeLabel;
	JTable announcementsTbl;
	
	Collection<Course> values;
	JList<String> list;
	String[] courseNames;
	String courseName;

	public StudentGradesPanel(final JFrame parentFrame, final DataBases db, final User user, final Course course) {
		this.parentFrame = parentFrame;
		backBtn = new JButton("Back");
		gradeLabel = new JLabel("  ");
		
		gradeLabel.setText(db.getGradesDB().get(course));
		System.out.println("#course " + course.getCourseName());
		System.out.println("#grade " + db.getGradesDB().get(course));
		gradeLabel.setSize(5,10);
		
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new StudentEnrolledCoursesPanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		this.add(gradeLabel);
		this.add(backBtn);
	}
}