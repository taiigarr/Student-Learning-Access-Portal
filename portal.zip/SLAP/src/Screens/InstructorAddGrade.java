package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import portal.Course;
import portal.DataBases;
import portal.Instructor;
import portal.User;

public class InstructorAddGrade extends JPanel{

	private static final long serialVersionUID = 1L;
	public JButton butt;
	private JLabel caption;
	private Instructor instructor;
	private String courseName;
	private JTextField gradeInput;
	private Collection<Course> values;
	private JList<String> list; 
	private String[] courseNames;

	public InstructorAddGrade (final JFrame parentFrame, final DataBases db, final User user, final Course course){ //,  
		gradeInput = new JTextField(10);
		caption = new JLabel("Add grade");
		butt = new JButton("Add");
		this.add(caption);
		this.add(gradeInput);
		this.add(butt);
		
		butt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
//				instructor = (Instructor) user;
				db.getGradesDB().put(course, gradeInput.getText());
				System.out.println("DB course: " + course);
				System.out.println("Grade input: " + gradeInput.getText());
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
		});
	}
}
