package Screens;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import portal.*;

public class LoginPanel extends JPanel{
	final JFrame parentFrame;
	
	JButton loginBtnl;
	JLabel userLbl;
	JTextField userTxt;
	JLabel passwordLbl;
	JTextField passwordTxt;
	
	public LoginPanel(final JFrame parentFrame, final DataBases db) {
		db.saveDatabases();
		
		this.parentFrame = parentFrame;
		this.parentFrame.setTitle("Student Learning Access Portal");
		JButton loginBtn = new JButton("Login");
		JLabel userLbl = new JLabel("User: ");
		final JTextField userTxt = new JTextField(10);
		JLabel passwordLbl = new JLabel("Password: ");
		final JTextField passwordTxt = new JTextField(10);

		loginBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				User user = db.getUsersDB().get(userTxt.getText()+";"+passwordTxt.getText());
				if(user==null) { return; }
				parentFrame.setTitle(userTxt.getText());
				
				parentFrame.getContentPane().removeAll();
				switch (user.getUserType()) {
					case "student":
						parentFrame.getContentPane().add(new StudentWelcomePanel(parentFrame, db, user)); break;
					case "admin":
						parentFrame.getContentPane().add(new AdminWelcomePanel(parentFrame, db, user)); break;
					case "instructor":
						parentFrame.getContentPane().add(new InstructorWelcomePanel(parentFrame, db, user)); break;
					default: System.out.println("ERROR IN LOGIN PAGE USER TYPE"); 
				}
				parentFrame.revalidate();
				parentFrame.repaint();
				
			}
        });
		
		
		this.add(new JLabel("Login"));
		this.add(loginBtn);
		this.add(userLbl);
		this.add(userTxt);
		this.add(passwordLbl);
		this.add(passwordTxt);
	}

}
