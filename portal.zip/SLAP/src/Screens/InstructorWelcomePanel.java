package Screens;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import portal.DataBases;
import portal.Instructor;
import portal.User;

public class InstructorWelcomePanel extends JPanel{

	JLabel welcomeLbl;
	JButton enrollBtn;
	JButton viewCoursesBtn;
	JButton logoutBtn;
	
	
	public InstructorWelcomePanel(final JFrame parentFrame, final DataBases db, final User user) {
		JButton viewCourseBtn = new JButton("View Course");
		JButton addCoursesBtn = new JButton("Add Courses");
		JButton logoutBtn = new JButton("Logout");

		this.add(new JLabel("Welcome"));
		this.add(viewCourseBtn);
		this.add(addCoursesBtn);
		this.add(logoutBtn);
		
		logoutBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new LoginPanel(parentFrame, db));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		viewCourseBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorViewCoursesPanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
		});
		addCoursesBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorAddCoursesPanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
		});
	}

}
