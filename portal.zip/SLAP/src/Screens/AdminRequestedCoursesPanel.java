package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTable;

import portal.Admin;
import portal.Course;
import portal.DataBases;
import portal.User;

public class AdminRequestedCoursesPanel extends JPanel {
	JFrame parentFrame;
	
	JLabel requestedLbl;
	JButton acceptBtn;
	JButton declineBtn;
	JButton backBtn;
	JTable studentListTbl;
	
	Collection<Course> values;
	JList<String> list ;
	String[] courseNames;
	String courseName;
		
	User admin;
	
	public AdminRequestedCoursesPanel(final JFrame parentFrame, final DataBases db, final User user) {
		this.parentFrame = parentFrame;
		this.admin = user;
		
		requestedLbl = new JLabel("Requested Courses");
		studentListTbl = new JTable();
		acceptBtn = new JButton("Accept");
		declineBtn = new JButton("Decline");
		backBtn = new JButton("Back");
		
		values = db.getReqCoursesDB().values();
		Course[] entry = (Course[]) values.toArray(new Course[values.size()]); //x.toArray (new Foo[x.size ()])
		courseNames = new String[entry.length];
		for (int i=0; i<entry.length; i++)
			courseNames[i] = entry[i].getCourseName();
		list = new JList<String>(courseNames); //data has type Object[]
		
		if ( db.getReqCoursesDB().isEmpty() )
		{
			declineBtn.setEnabled(false);
			acceptBtn.setEnabled(false);
		}
		
		declineBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				courseName = list.getSelectedValue();
				if (!db.getReqCoursesDB().isEmpty())
					db.getReqCoursesDB().remove(courseName);	// remove course from req course db
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		acceptBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				courseName = list.getSelectedValue();		// add course to course db
				db.getCoursesDB().put(courseName, db.getReqCoursesDB().remove(courseName));
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		
		this.add(requestedLbl);
		this.add(list);
		this.add(studentListTbl);
		this.add(acceptBtn);
		this.add(declineBtn);
		this.add(backBtn);
	}
}