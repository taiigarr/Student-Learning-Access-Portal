package Screens;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import portal.DataBases;
import portal.Instructor;
import portal.User;

public class InstructorAddCoursesPanel extends JPanel implements ActionListener {
	private JLabel caption;
	public JTextField input;
	public final JButton butt;
	private Instructor instructor;
	private String courseName;
	
	public InstructorAddCoursesPanel(final JFrame parentFrame, final DataBases db, final User user){ //,  
		caption = new JLabel("Add course");
//		caption.setText();
		input = new JTextField(10);
		butt = new JButton("Add");
		this.add(caption);
		this.add(input);
		this.add(butt);
		butt.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				courseName = input.getText();	// downcasting issue
				//instructor = (Instructor) instructor;
				instructor = (Instructor) user;
				instructor.addReqCourse(courseName, db);
//				db.saveDatabases();
//				course = db.getReqCoursesDB().get(courseName);
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
				
			}
		});
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getSource() == butt)
		{
			//instructor.getCourse(0).setCourseName(input.getText());
//			System.out.println("Balls!");
		}	
	}
}
