package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTable;

import portal.Course;
import portal.DataBases;
import portal.Student;
import portal.User;

public class StudentEnrollPanel extends JPanel{
	JFrame parentFrame;
	
	JLabel enrollLbl;
	JButton enrollBtn;
	JButton backBtn;
	JTable studentListTbl;
	
	Collection<Course> values;
	JList<String> list ;
	String[] courseNames;
	String courseName;
	Course course;
	boolean isListEmpty;
	
	public StudentEnrollPanel(final JFrame parentFrame, final DataBases db, final User user) {
		this.parentFrame = parentFrame;
		
		enrollLbl = new JLabel("Enroll in Courses");
		enrollBtn = new JButton("Enroll");
		backBtn = new JButton("Back");
		studentListTbl = new JTable();
		
		values = db.getCoursesDB().values();
		Course[] entry = (Course[]) values.toArray(new Course[values.size()]); //x.toArray (new Foo[x.size ()])
		courseNames = new String[entry.length];
		isListEmpty = true;
		
		for (int i=0; i<entry.length; i++)
		{
			if (!entry[i].getEnrolled())
			{
				courseNames[i] = entry[i].getCourseName();
				isListEmpty = false;
			}
		}
		
		if (isListEmpty){		// disbale butt if list is empty
			System.out.println("EMPTY");
			enrollBtn.setEnabled(false);
			repaint();
		}
		list = new JList<String>(courseNames); //data has type Object[]
		
		enrollBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				courseName = list.getSelectedValue();
				course = db.getCoursesDB().get(courseName);
				course.setEnrolled(true);
				db.getStuCoursesDB().put(courseName, course);
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new StudentWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new StudentWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		
		this.add(enrollLbl);
		this.add(list);
		this.add(enrollBtn);
		this.add(backBtn);
		this.add(studentListTbl);
	}

}
