package Screens;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import portal.Course;
import portal.DataBases;
import portal.Instructor;
import portal.User;

public class InstructorAddAnnouncement extends JPanel {

	public JButton butt;
	private JLabel caption;
	private Instructor instructor;
	private String courseName;
	private JTextArea annInput;
	private Collection<Course> values;
	private JList<String> list ; 
	private String[] courseNames;
	
	public InstructorAddAnnouncement(final JFrame parentFrame, final DataBases db, final User user, final Course course){ //,  
		caption = new JLabel("Add announcement");
		annInput = new JTextArea(10, 25);
		annInput.setBorder(BorderFactory.createLineBorder(Color.black, 2));
//		caption.setText();
		butt = new JButton("Add");
		this.add(caption);
		this.add(annInput);
		this.add(butt);
		
		butt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				db.getAnnouncementsDB().put(course, annInput.getText());
//				instructor = (Instructor) user;
//				instructor.addReqCourse(courseName, db);
				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
		});
	}
}
