package Screens;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;

import portal.Course;
import portal.DataBases;
import portal.User;

public class InstructorViewCoursesPanel extends JPanel {
	private JLabel caption;
	private Collection<Course> values;
	private JList<String> list ; 
	private String[] courseNames;
	private String courseName;
	private Course course;
	public final JButton butt;
	public final JButton annBtn;
	public final JButton gradeBtn;
	
	public InstructorViewCoursesPanel(final JFrame parentFrame, final DataBases db, final User user){ //,  
		caption = new JLabel("Add course");
		values = db.getCoursesDB().values();
		Course[] entry = (Course[]) values.toArray(new Course[values.size()]); //x.toArray (new Foo[x.size ()])
		courseNames = new String[entry.length];
		for (int i=0; i<entry.length; i++)
			courseNames[i] = entry[i].getCourseName();
		list = new JList<String>(courseNames); //data has type Object[]
		butt = new JButton("Back");
		annBtn = new JButton("Add Announcement");
		gradeBtn = new JButton("Add Grade");
		this.add(caption);
		this.add(list);
		this.add(butt);	
		this.add(annBtn);
		this.add(gradeBtn);
		list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		list.setVisibleRowCount(-1);
		
		butt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub				
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorWelcomePanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();	
			}
		});
		annBtn.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				courseName = list.getSelectedValue();
				course = db.getCoursesDB().get(courseName);
				System.out.println("Course " + courseName);
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorAddAnnouncement(parentFrame, db, user, course));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
		});
		gradeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				courseName = list.getSelectedValue();
				course = db.getCoursesDB().get(courseName);
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new InstructorAddGrade(parentFrame, db, user, course));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
		});
	}
}
