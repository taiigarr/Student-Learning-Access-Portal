package Screens;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import portal.Admin;
import portal.DataBases;
import portal.Instructor;
import portal.Student;
import portal.User;

public class AdminWelcomePanel extends JPanel{
//	JFrame parentFrame;
	
	JLabel welcomeLbl;
	JButton enrollBtn;
	JButton viewCoursesBtn;
	JButton logoutBtn;

	//private User user;
	
	
	public AdminWelcomePanel(final JFrame parentFrame, final DataBases db, final User user) {
//		this.parentFrame = parentFrame;
//		this.user = user;
		
		JButton coursesBtn = new JButton("Existing Courses");
		JButton reqCoursesBtn = new JButton("Requested Courses");
		JButton logoutBtn = new JButton("Logout");

		coursesBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminExistingCoursesPanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		reqCoursesBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new AdminRequestedCoursesPanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		logoutBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new LoginPanel(parentFrame, db));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		
		this.add(new JLabel("Welcome"));
		this.add(coursesBtn);
		this.add(reqCoursesBtn);
		this.add(logoutBtn);
	}

}
