package Screens;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTable;

import portal.Course;
import portal.DataBases;
import portal.Student;
import portal.User;

public class StudentAnnouncementsPanel extends JPanel {
	JFrame parentFrame;

	JLabel announcementsLbl;
	JLabel annTextLabel;
	JButton backBtn;
	JTable announcementsTbl;
	
	Collection<Course> values;
	JList<String> list;
	String[] courseNames;
	String courseName;

	public StudentAnnouncementsPanel(final JFrame parentFrame, final DataBases db, final User user, final Course course) {
		this.parentFrame = parentFrame;
		announcementsLbl = new JLabel("ANNOUNCEMENTS: ");
		
		annTextLabel = new JLabel("");
		backBtn = new JButton("Back");
		announcementsTbl = new JTable();
		System.out.println(course);
		System.out.println(db.getAnnouncementsDB().get(course));
		annTextLabel.setText(db.getAnnouncementsDB().get(course));
		annTextLabel.setSize(25, 10);
		//System.out.printf("#Announcement: %s\n", db.getAnnouncementDB().get(course));
		
		backBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				parentFrame.getContentPane().removeAll();
				parentFrame.getContentPane().add(new StudentEnrolledCoursesPanel(parentFrame, db, user));
				parentFrame.revalidate();
				parentFrame.repaint();
			}
        });
		this.add(announcementsLbl);
		this.add(annTextLabel);
		this.add(backBtn);	
	}
}


