package portal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Student extends User implements Serializable{
	private Map<String, String> grade = new HashMap<String, String>();
	private String message;
	private ArrayList<Course> course;
	public final static String userType = "student";
	
	public Student(){
		super(userType);
		course = new ArrayList<Course>();	
	}
	// Obtain grade from grade map
	public String getGrade(String courseName){
		return grade.get(courseName);
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
