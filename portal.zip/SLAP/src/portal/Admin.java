package portal;



public class Admin extends User {
//	final private String USERTYPE="Admin";
	private DataBases db; //= DataBases.loadDataBases();
	public final static String userType = "admin";
	
	public Admin()
	{
		super(userType);
	}
	
	public void addCourse(String courseName, DataBases db)
	{ 
		db.getCoursesDB().put(courseName, db.getReqCoursesDB().remove(courseName));
	}
	public void removeCourse(String courseName, DataBases db)
	{
		db.getCoursesDB().remove(courseName); //yay
	}
	
}
