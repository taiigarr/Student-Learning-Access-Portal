package portal;
import java.io.Serializable;
import java.util.ArrayList;


public class Instructor extends User implements Serializable{
		// TODO Auto-generated constructor stub
	private String grade;
	private String announcements;
	private String message;
	public final static String userType = "instructor";

	public Instructor() {
		super(userType);
	}

	public String getGrade()
	{
		return grade;
	}
	public void setGrade(String grade)
	{
		this.grade = grade;
	}
	
	public String getAnnouncements() {
		return announcements;
	}

	public void setAnnouncements(String announcements) {
		this.announcements = announcements;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void addReqCourse(String courseName, DataBases db) //, Course course
	{
		db.getReqCoursesDB().put(courseName, new Course(courseName)); // hehe :p
		db.saveDatabases();
	}
	public Course getCourse(String courseName, DataBases db)
	{
		return db.getReqCoursesDB().get(courseName);
	}
	
	/*
	public void setCourseName(String courseName, int index)
	{
		// CHANGED 0?
		course.get(index).setCourseName(courseName);
	}
	public String getCourseName(int index)
	{
		return course.get(index).getCourseName();
	}
	public Course getCourse(int index)
	{
		return course.get(index);
	}
	*/
}
