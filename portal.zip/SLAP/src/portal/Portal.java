package portal;
import java.awt.TextField;
import java.awt.event.*;
import java.io.Serializable;
import java.util.*; 
import javax.swing.event.*;
import javax.swing.*;

public class Portal extends JComponent implements Serializable{
//	ArrayList<Course> Courses = new ArrayList<Course>();
	Map<String, String> map = new HashMap<String, String>();
	Student student;
	Instructor instructor;
	private int index;
	private TextField username;
	private TextField password;
	private TextField courseNameTF;
	private TextField grade;
	
	public String getUsername() {
		return username.getText();
	}
	public void setUsername(TextField username) {
		this.username = username;
	}
	public String getPassword() {
		return password.getText();
	}
	public void setPassword(TextField password) {
		this.password = password;
	}
	public boolean checkAuthentication(TextField username, TextField password)
	{
		if (username.getText().equals(this.username.getText()))
				if (password.getText().equals(this.password.getText()))
					;// PUT SOMETHING!!!	login(username);
		return false;
	}
	// Add user to dictionary
	public void include(String key, String val)
	{
		map.put(key, val);
	}
	// Get user value by username
	public String obtain(String key)
	{
		return map.get(key);
	}
	/*
	public void setCourseName(TextField courseNameTF){
		 instructor.setCourseName(courseNameTF.getText(), index) ;
	}
	*/
	public String getGrade()
	{
		return grade.getText();
	}
	/*
	public void setAnnouncement(String announcement, int index) {
		instructor.getCourse(index).setAnnouncement(announcement);
	}
	*/
	//component
}
