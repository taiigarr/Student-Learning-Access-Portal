package portal;

import java.io.Serializable;

public class Course implements Serializable{
	private boolean isEnrolled;
	private String courseName;
	private String announcement;
    
	public Course() { }
	
	public Course(String courseName)
	{
		this.courseName = courseName;
	}
	
	public void setEnrolled(boolean isEnrolled)
	{
		this.isEnrolled = isEnrolled;
	}
	public boolean getEnrolled()
	{
		return isEnrolled;
	}
	
	public void setCourseName(String courseName)
    {
        this.courseName=courseName;
    }
    public String getCourseName()
    {
        return courseName;
    }
    public String getAnnouncement(){
    	return announcement;
    }
    public void setAnnouncement(String announcement){
    	this.announcement = announcement; 
    }
    
}
