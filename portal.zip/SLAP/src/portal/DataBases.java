package portal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


public class DataBases implements Serializable {

	private Map<String, User> userDB;
	private Map<String, Course> coursesDB;
	private Map<String, Course> reqCourseDB;
	private Map<String, Course> stuCourseDB;
	private Map<Course, String> announcementsDB;
	private Map<Course, String> gradesDB;
	
	public DataBases() {
		userDB = new HashMap<String, User>();
		coursesDB = new HashMap<String, Course>();
		reqCourseDB = new HashMap<String, Course>();
		stuCourseDB = new HashMap<String, Course>();
		announcementsDB = new HashMap<Course, String>();
		gradesDB = new HashMap<Course, String>();
		
		userDB.put("student;student", new Student()); // HERE
		userDB.put("admin;admin", new Admin()); // shut up!
		userDB.put("instructor;instructor", new Instructor());
	}
	
	public Map<String,User> getUsersDB(){ return userDB; }
	public Map<String,Course> getCoursesDB(){ return coursesDB; }
	public Map<String,Course> getReqCoursesDB(){ return reqCourseDB; }
	public Map<String,Course> getStuCoursesDB() {return stuCourseDB; }
	public Map<Course,String> getAnnouncementsDB() {return announcementsDB; }
	public Map<Course,String> getGradesDB() { return gradesDB; }

	public void saveDatabases(){
		File f = new File("db.dat");
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream(f));
			out.writeObject(this);
			out.close();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public static DataBases loadDataBases(){
		File f = new File("db.dat");
		
		ObjectInputStream in = null;
		if(f.exists()){
			try {
				in = new ObjectInputStream(new FileInputStream(f));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(1);
			}
			DataBases db = null;
			try {
				db = (DataBases) in.readObject();
			} catch (ClassNotFoundException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.exit(1);
			}
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.exit(1);
			}
			System.out.println("Loaded databases");
			return db;
		} else {
			System.out.println("No databases found.. making new one for you");
			return new DataBases();
		}
	}
}
