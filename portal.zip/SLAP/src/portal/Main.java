package portal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import Screens.InstructorAddCoursesPanel;
//import portal.Screens.StudentGradesPanel;
import Screens.LoginPanel;

// instructor should have access to student's courses to view (their) grades
public class Main {
	static Admin admin;
	 static Instructor instructor;
	 static LoginPanel loginPage;
	 static Course course;
	 static String courseName;
	
	public static void main(String[] args) {
		
		final DataBases db = DataBases.loadDataBases();
		JFrame frame = new JFrame("Student Learning Access Portal");
		frame.setSize(500, 300);
		admin = new Admin();
		course = new Course();
		
		//course.setCourseName("Computer Graphics");
		//every pane;l need to pass along the jframe, database and the currentuser
		instructor = new Instructor(); //, course
		loginPage = new LoginPanel(frame, db); 
		frame.add(loginPage);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}