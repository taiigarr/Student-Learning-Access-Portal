package portal;

import java.io.Serializable;

public class User implements Serializable{
    private String courseName;
    private String userType;
     
    public User(String userType)
    {
        this.userType = userType;
    }
     public String getUserType(){
    	return userType;
    }
    public void setUserType(String userType){
    	this.userType = userType;
    }
    
}